
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class adapter {
	
	static Connection baglan;
	static Statement stat;
	
	static ResultSet baglanti_yap(){
		ResultSet myRs = null;
		try {
			baglan = (Connection) DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=follow_your_customer;user=admin;password=admin");
			stat = (Statement) baglan.createStatement();
			myRs = stat.executeQuery("select * from Contact");
				
		}catch(Exception es) {
			
		}
		return myRs;
	}
	
	static ResultSet ID_Goster(){
		ResultSet myRs = null;
		try {
			baglan = (Connection) DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=follow_your_customer;user=admin;password=admin");
			stat = (Statement) baglan.createStatement();
			myRs = stat.executeQuery("select * from ID");
				
		}catch(Exception es) {
			
		}
		return myRs;
	}
	
	static ResultSet Products_Goster(){
		ResultSet myRs = null;
		try {
			baglan = (Connection) DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=follow_your_customer;user=admin;password=admin");
			stat = (Statement) baglan.createStatement();
			myRs = stat.executeQuery("select * from Products_Owned");
				
		}catch(Exception es) {
			
		}
		return myRs;
	}
	
	
	static ResultSet baglanti_kapat(){
		ResultSet myRs = null;
		try {
			baglan.close();
				
		}catch(Exception es) {
			
		}
		return myRs;
	}
	
	static void ekle(String yeni_ekle) {
		try {
			stat.executeUpdate(yeni_ekle);			
		}catch(Exception es) {
			
		}
	}
	
	static void sil(String varolan_sil) {
		try {
			stat.executeUpdate(varolan_sil);
		}catch(Exception es) {
			
		}
	}

}
