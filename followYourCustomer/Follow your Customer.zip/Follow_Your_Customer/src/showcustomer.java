import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class showcustomer extends JFrame {

	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JTable table;
	
	DefaultTableModel modelim = new DefaultTableModel();
	
	
	Object[] Contact_kolon_isimleri = {"Id","Phone","Fax","Mail","Social Media"};
	Object[] id_kolon_isimleri = {"Id","CitizenShip_Number","HomeLand","Year","Job","Monthly Earnings"};
	Object[] products_kolon_isimleri = {"Id","Build","Vehicle","Land"};
	Object[] Contact_satirlar = new Object[5];
	Object[] id_satirlar = new Object[6];
	Object[] products_satirlar = new Object[4];
	
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					showcustomer frame = new showcustomer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public showcustomer() {
		setBounds(100, 100, 766, 494);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 122, 724, 312);
		contentPane.add(scrollPane);
		
		
		table = new JTable();
		
		table.setModel(modelim);
		table.setBounds(31, 180, 429, 235);
		scrollPane.setViewportView(table);
		
		btnNewButton = new JButton("Show Contacts");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				modelim.setRowCount(0);
				try {
					ResultSet myRs = adapter.baglanti_yap();
					
					
				    while(myRs.next()) {
				        Contact_satirlar[0] = myRs.getString("id");
				        Contact_satirlar[1] = myRs.getString("Phone");
				        Contact_satirlar[2] = myRs.getString("Fax");
				        Contact_satirlar[3] = myRs.getString("Mail");
				        Contact_satirlar[4] = myRs.getString("Social_Media");
				        modelim.setColumnIdentifiers(Contact_kolon_isimleri);
						modelim.addRow(Contact_satirlar);
				       		
				        
				    }					
					table.setModel(modelim);
					JOptionPane.showMessageDialog(null, "Show Customer Table Success");
					adapter.baglanti_kapat();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(296, 48, 170, 42);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Show ID");
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				modelim.setRowCount(0);
				try {
					ResultSet myRs = adapter.ID_Goster();
					
					
				    while(myRs.next()) {
				        id_satirlar[0] = myRs.getString("id");
				        id_satirlar[1] = myRs.getString("CitizenShip_Number");
				        id_satirlar[2] = myRs.getString("HomeLand");
				        id_satirlar[3] = myRs.getString("year");
				        id_satirlar[4] = myRs.getString("Job");
				        id_satirlar[5] = myRs.getString("Monthly_Earnings");
				        modelim.setColumnIdentifiers(id_kolon_isimleri);
						modelim.addRow(id_satirlar);
				       		
				        
				    }					
					table.setModel(modelim);
					JOptionPane.showMessageDialog(null, "Show ID Table Success");
					adapter.baglanti_kapat();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setBounds(85, 48, 170, 42);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Show Products Owned");
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				modelim.setRowCount(0);
				try {
					ResultSet myRs = adapter.Products_Goster();
					
					
				    while(myRs.next()) {
				        products_satirlar[0] = myRs.getString("id");
				        products_satirlar[1] = myRs.getString("Build");
				        products_satirlar[2] = myRs.getString("Vehicle");
				        products_satirlar[3] = myRs.getString("Land");
				        
				        modelim.setColumnIdentifiers(products_kolon_isimleri);
						modelim.addRow(products_satirlar);
				       		
				        
				    }					
					table.setModel(modelim);
					JOptionPane.showMessageDialog(null, "Show Products Owned Table Success");
					adapter.baglanti_kapat();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_2.setBounds(496, 48, 170, 42);
		contentPane.add(btnNewButton_2);
		//contentPane.add(table);
		
	}
}
