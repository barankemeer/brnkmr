import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;

public class login2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login2 frame = new login2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login2() {
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton2 = new JButton("LOGIN");
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			try {
				  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			      String url = "jdbc:sqlserver://localhost:1433;databaseName=follow_your_customer;user=admin;password=admin";
			      Connection con = DriverManager.getConnection(url);
			      String sql = "Select * from users where username=? and password=?"; 
			      PreparedStatement pst = con.prepareStatement(sql);
			      pst.setString(1,textField.getText());//kontrol1
			      pst.setString(2,passwordField.getText());//kontrol2
			      ResultSet rs = pst.executeQuery();
			      if(rs.next()){
			          JOptionPane.showMessageDialog(null,"LOGIN SUCCESS");
			          newcustomer frm2 = new newcustomer();
			          frm2.setVisible(true);
			    
			      }
			       
			          
			      
				else
			
				{
			          JOptionPane.showMessageDialog(null,"TRY AGAIN PLEASE");
			          textField.setText("");
			          passwordField.setText("");
			      }
			        con.close();
		
			}catch(Exception es){
				JOptionPane.showMessageDialog(null,es.toString());
			}
			
			
			
			}
			
		});
		
		
		btnNewButton2.setBounds(180, 170, 97, 25);
		contentPane.add(btnNewButton2);
		
		textField = new JTextField();
		textField.setFont(new Font("Bahnschrift", Font.BOLD, 15));
		textField.setBackground(Color.BLACK);
		textField.setForeground(Color.WHITE);
		textField.setBounds(40, 65, 116, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(Color.BLACK);
		passwordField.setForeground(Color.WHITE);
		passwordField.setBounds(40, 134, 116, 22);
		contentPane.add(passwordField);
		
		lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(40, 36, 116, 16);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(40, 112, 97, 16);
		contentPane.add(lblNewLabel_1);
		}
	}
	

