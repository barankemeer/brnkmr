import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class newcustomer extends JFrame {

	private JPanel contentPane;
	private JTextField ctnumber;
	private JTextField homeland;
	private JTextField yearofborn;
	private JTextField job;
	private JTextField monterning;
	private JTextField phone;
	private JTextField fax;
	private JTextField mail;
	private JTextField socialmedia;
	private JTextField build;
	private JTextField vehicle;
	private JTextField land;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					newcustomer frame = new newcustomer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public newcustomer() {
		setBounds(100, 100, 706, 595);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setForeground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(67, 13, 56, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblHomeland = new JLabel("HomeLand");
		lblHomeland.setBounds(67, 93, 90, 16);
		contentPane.add(lblHomeland);
		
		JLabel lblYearOfBorn = new JLabel("Year of Born");
		lblYearOfBorn.setBounds(67, 145, 103, 16);
		contentPane.add(lblYearOfBorn);
		
		JLabel lblJob = new JLabel("Job");
		lblJob.setBounds(67, 190, 116, 16);
		contentPane.add(lblJob);
		
		JLabel lblMonthlyEarnings = new JLabel("Monthly Earnings");
		lblMonthlyEarnings.setBounds(67, 237, 103, 16);
		contentPane.add(lblMonthlyEarnings);
		
		JLabel lblContact = new JLabel("Contact");
		lblContact.setBounds(432, 13, 56, 16);
		contentPane.add(lblContact);
		
		JLabel lblFax = new JLabel("Fax");
		lblFax.setBounds(432, 93, 56, 16);
		contentPane.add(lblFax);
		
		JLabel lblMail = new JLabel("Mail");
		lblMail.setBounds(432, 145, 56, 16);
		contentPane.add(lblMail);
		
		JLabel lblSocialMedia = new JLabel("Social Media");
		lblSocialMedia.setBounds(432, 190, 97, 16);
		contentPane.add(lblSocialMedia);
		
		JLabel lblProductsOwned = new JLabel("Products Owned");
		lblProductsOwned.setBounds(149, 288, 97, 16);
		contentPane.add(lblProductsOwned);
		
		ctnumber = new JTextField();
		ctnumber.setForeground(Color.BLACK);
		ctnumber.setFont(new Font("Segoe UI", Font.BOLD, 15));
		ctnumber.setBounds(67, 58, 116, 22);
		contentPane.add(ctnumber);
		ctnumber.setColumns(10);
		
		homeland = new JTextField();
		homeland.setForeground(Color.BLACK);
		homeland.setFont(new Font("Segoe UI", Font.BOLD, 15));
		homeland.setBounds(67, 108, 116, 22);
		homeland.setColumns(10);
		contentPane.add(homeland);
		
		yearofborn = new JTextField();
		yearofborn.setForeground(Color.BLACK);
		yearofborn.setFont(new Font("Segoe UI", Font.BOLD, 15));
		yearofborn.setBounds(67, 159, 116, 22);
		yearofborn.setColumns(10);
		contentPane.add(yearofborn);
		
		job = new JTextField();
		job.setForeground(Color.BLACK);
		job.setFont(new Font("Segoe UI", Font.BOLD, 15));
		job.setBounds(67, 207, 116, 22);
		job.setColumns(10);
		contentPane.add(job);
		
		monterning = new JTextField();
		monterning.setForeground(Color.BLACK);
		monterning.setFont(new Font("Segoe UI", Font.BOLD, 15));
		monterning.setColumns(10);
		monterning.setBounds(67, 253, 116, 22);
		contentPane.add(monterning);
		
		phone = new JTextField();
		phone.setForeground(Color.BLACK);
		phone.setFont(new Font("Segoe UI", Font.BOLD, 15));
		phone.setColumns(10);
		phone.setBounds(429, 58, 116, 22);
		contentPane.add(phone);
		
		fax = new JTextField();
		fax.setForeground(Color.BLACK);
		fax.setFont(new Font("Segoe UI", Font.BOLD, 15));
		fax.setColumns(10);
		fax.setBounds(429, 110, 116, 22);
		contentPane.add(fax);
		
		mail = new JTextField();
		mail.setForeground(Color.BLACK);
		mail.setFont(new Font("Segoe UI", Font.BOLD, 15));
		mail.setColumns(10);
		mail.setBounds(429, 159, 116, 22);
		contentPane.add(mail);
		
		socialmedia = new JTextField();
		socialmedia.setForeground(Color.BLACK);
		socialmedia.setFont(new Font("Segoe UI", Font.BOLD, 15));
		socialmedia.setColumns(10);
		socialmedia.setBounds(429, 207, 116, 22);
		contentPane.add(socialmedia);
		
		build = new JTextField();
		build.setForeground(Color.BLACK);
		build.setFont(new Font("Segoe UI", Font.BOLD, 15));
		build.setColumns(10);
		build.setBounds(149, 345, 116, 22);
		contentPane.add(build);
		
		JButton btnNewButton = new JButton("Create");
		btnNewButton.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		btnNewButton.setBackground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String ct_number,homeLand,yearOfBorn,jobb,Monterning,Phone;
					String Fax,Mail,socialMedia,Build,Vehicle,Land,sql_sorgu2;
					ct_number = ctnumber.getText();
					homeLand = homeland.getText();
					yearOfBorn = yearofborn.getText();
					jobb = job.getText();
					Monterning = monterning.getText();
					Phone = phone.getText();
					Fax = fax.getText();
					Mail = mail.getText();
					socialMedia = socialmedia.getText();
					Build = build.getText();
					Vehicle = vehicle.getText();
					Land = land.getText();
					
					
					
					if(ct_number.trim().equals("") || homeLand.trim().equals("") || yearOfBorn.trim().equals("") ||
					   jobb.trim().equals("")|| Monterning.trim().equals("") || Phone.trim().equals("") || Fax.trim().equals("") ||
					   Mail.trim().equals("") || socialMedia.trim().equals("") || Build.trim().equals("") || Vehicle.trim().equals("") ||
					   Land.trim().equals("")) {
						   JOptionPane.showMessageDialog(null, "PLEASE TYPE ALL SPEACE");
					}else {
						adapter.baglanti_yap();
						sql_sorgu2 = "insert into Contact values(" + Phone + "," + Fax + "," + "'" + Mail + "'" + "," + "'" +socialMedia + "')";
						adapter.ekle(sql_sorgu2);
						String sql_sorgu3 = "insert into Products_Owned values(" + "'" + Build + "'" +"," + "'" + Vehicle + "'" +"," + "'" + Land + "')";
						adapter.ekle(sql_sorgu3);
						String sql_sorgu4 = "insert into ID values(" + ct_number + "," + "'" + homeLand + "'" +"," + "'" + yearOfBorn + "'" + "," + "'" + jobb + "'" + "," + Monterning +")";
						adapter.ekle(sql_sorgu4);
						JOptionPane.showMessageDialog(null, "SUCCSESS LOG");
						adapter.baglanti_kapat();
					}
					
				}catch(Exception es) {
					JOptionPane.showMessageDialog(null, "CONNECTION ERROR " + es.toString());
				}
				
			}
		});
		btnNewButton.setBounds(479, 363, 97, 25);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1_1 = new JLabel("CitizenShip Number");
		lblNewLabel_1_1.setBounds(67, 39, 127, 16);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setBounds(432, 39, 56, 16);
		contentPane.add(lblPhone);
		
		JLabel lblNewLabel_9_1 = new JLabel("Build");
		lblNewLabel_9_1.setBounds(149, 328, 56, 16);
		contentPane.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_2 = new JLabel("Vehicle");
		lblNewLabel_9_2.setBounds(149, 380, 56, 16);
		contentPane.add(lblNewLabel_9_2);
		
		JLabel lblNewLabel_9_3 = new JLabel("Land");
		lblNewLabel_9_3.setBounds(149, 427, 56, 16);
		contentPane.add(lblNewLabel_9_3);
		
		vehicle = new JTextField();
		vehicle.setForeground(Color.BLACK);
		vehicle.setFont(new Font("Segoe UI", Font.BOLD, 15));
		vehicle.setColumns(10);
		vehicle.setBounds(149, 397, 116, 22);
		contentPane.add(vehicle);
		
		land = new JTextField();
		land.setForeground(Color.BLACK);
		land.setFont(new Font("Segoe UI", Font.BOLD, 15));
		land.setColumns(10);
		land.setBounds(149, 448, 116, 22);
		contentPane.add(land);
	}
}
